import { Tag } from './tag';

describe('Tag', () => {
  it('should create an instance', () => {
    expect(new Tag()).toBeTruthy();
  });
});
