import { Recursos } from './recursos';

describe('Recursos', () => {
  it('should create an instance', () => {
    expect(new Recursos()).toBeTruthy();
  });
});
