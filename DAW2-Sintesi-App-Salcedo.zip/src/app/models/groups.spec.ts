import { Groups } from './groups';

describe('Groups', () => {
  it('should create an instance', () => {
    expect(new Groups()).toBeTruthy();
  });
});
